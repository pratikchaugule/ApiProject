package com.jbk.dao;

import java.util.List;

import com.jbk.entity.Student;

public interface StudentDao {
public boolean saveStudentInfo(Student student);
//get student info by id
public Student getStudentById(int sid);
//get all student info
public List<Student>getAllStudent();
//get StudentByname
public Student getStudentByname(String StudentName);
//delete Student by id
public boolean DeleteProductByid(int sid);
//update product
public boolean updateStudent(Student student);
//Get Product by asscending order
public List<Student>getStudentByAscendingOrder();
//Get Product by descending order
public List<Student>getStudentByDescendingOrder();
//Get max percentage
public Student getTopper();
//Get Min per
public Student getLowerStudent();
//Get avg per
public double getAvgPercentage();
 //get greater per
public List<Student>getGreaterPer(double per);




}

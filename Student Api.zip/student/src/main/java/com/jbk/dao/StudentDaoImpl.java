package com.jbk.dao;

import java.security.cert.CRL;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jbk.entity.Student;
@Repository
public class StudentDaoImpl implements StudentDao {
	@Autowired
	SessionFactory sf;
	
	@Override
	public boolean saveStudentInfo(Student student) {
		 boolean  save=false;
		 Session session=null;
		try {
			 session=sf.openSession();
				Transaction tr=session.beginTransaction();
				session.save(student);
			    tr.commit();
			    save=true;
			
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		if(session!=null) {
			session.close();
		}
		
		return save;
	}

	@Override
	public Student getStudentById(int sid) {
		Session session=sf.openSession();
		Student student=null;
		try {
			 student=session.get(Student.class, sid);
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			if(session!=null) {
				session.close();
			}
		}
		return student;
	}

	@Override
	public List<Student> getAllStudent() {
		Session session=sf.openSession();
		List<Student>li=null;
		try {
			Criteria cr=session.createCriteria(Student.class);
			li=cr.list();
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			if(session!=null) {
				session.close();
			}
		}
		return li;
	}

	@Override
	public Student getStudentByname(String name) {
		Session session=sf.openSession();
		Student student=null;
		try {
			Criteria cr=session.createCriteria(Student.class);
			cr.add(Restrictions.eq("studentName", name));
			List<Student>li=cr.list();
			if(!li.isEmpty()) {
				student=li.get(0);
			}
			
		} catch (Exception e) {
		  e.printStackTrace();
		}
		return student;
	}

	@Override
	public boolean DeleteProductByid(int sid) {
		Session session=sf.openSession();
		boolean isDeleted=false;
		try {
			Student student=session.get(Student.class, sid);
			Transaction tr=session.beginTransaction();
			session.delete(student);
			tr.commit();
			isDeleted=true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isDeleted;
	}

	@Override
	public boolean updateStudent(Student student) {
		Session session=sf.openSession();
		boolean isUpdated=false;
		try {
			Student student1=session.get(Student.class,student.getStudentId());
			Transaction tr=session.beginTransaction();
			session.evict(student1);
			if(student1!=null) {
			session.update(student);
			tr.commit();
			isUpdated=true;
			
			}
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return isUpdated;
	}

	@Override
	public List<Student> getStudentByAscendingOrder() {
		Session session=sf.openSession();
		List<Student>list=null;
		try {
			Criteria criteria=session.createCriteria(Student.class);
			criteria.addOrder(Order.asc("studentPer"));
			list=criteria.list();
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
		
	}

	@Override
	public List<Student> getStudentByDescendingOrder() {
	Session session=sf.openSession();
	List<Student>list1=null;
	try {
		Criteria cr=session.createCriteria(Student.class);
		cr.addOrder(Order.desc("studentPer"));
		list1=cr.list();
	} catch (Exception e) {
		e.printStackTrace();
	}
		return list1;
	}

	@Override
	public Student getTopper() {
		Session s=sf.openSession();
		Student student=null;
		Double per=0.0;
		try {
			Criteria cr=s.createCriteria(Student.class);
			Criteria cri=s.createCriteria(Student.class);
			cr.setProjection(Projections.max("studentPer"));
			List<Double>li=cr.list();
			per=li.get(0);
			cri.add(Restrictions.eq("studentPer", per));
		List<Student>li2=cri.list();
			student=li2.get(0);
			
			
		} catch (NullPointerException e) {
			e.printStackTrace();
		}
		return student; 
	}

	@Override
	public Student getLowerStudent() {
		Session session=sf.openSession();
		Student student=null;
		try {
			Criteria cr=session.createCriteria(Student.class);
  			Criteria cr2=session.createCriteria(Student.class);
  			cr.setProjection(Projections.min("studentPer"));
  			List<Double>li=cr.list();
  			Double min=li.get(0);
  			
  			cr2.add(Restrictions.eq("studentPer", min));
  			List<Student>li2=cr2.list();
  			student=li2.get(0);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			if(session!=null) {
				session.close();
			}
		}
		return student;
		
	}

	@Override
	public double getAvgPercentage() {
		Session session=sf.openSession();
		Double d=0.0;
		try {
			Criteria cr=session.createCriteria(Student.class);
			cr.setProjection(Projections.avg("studentPer"));
			List<Double>li=cr.list();
			d=li.get(0);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return d;
	}

	@Override
	public List<Student> getGreaterPer(double per) {
		Session session=sf.openSession();
		List<Student>list=null;
		try {
			Criteria cr=session.createCriteria(Student.class);
			cr.add(Restrictions.gt("studentPer", per));
			list=cr.list();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	
	

}

package com.jbk.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.jbk.entity.Student;
import com.jbk.exception.ProductAlreadyExists;
import com.jbk.service.StudentService;

@RestController
public class StudentController {
	@Autowired
	private StudentService stuservice;
	
	@PostMapping(value="saveStudent")
	public ResponseEntity<Boolean> saveStudent( @RequestBody  Student student) {
		boolean b=stuservice.saveStudentInfo(student);
		if(b) {
			 return new ResponseEntity<>(b, HttpStatus.CREATED);
		}
		else {
			 throw new ProductAlreadyExists("sorry Product Already Exists");
		}
		
		
		
		
	}
	@GetMapping(value="getStudentById/{studentId}")
	public ResponseEntity<Student> getStudentById( @PathVariable  int studentId) {
		Student student=stuservice.getStudentById(studentId);
		if(student!=null) {
			return new ResponseEntity<Student>(student,HttpStatus.OK);
		}
		else {
			return new ResponseEntity<Student>(HttpStatus.OK);
		}
	
	}
	@GetMapping(value="GetAllStudentInfo")
	public ResponseEntity<List>getAllStudentInfo(){
		List<Student>list=stuservice.getAllStudent();
		if(!list.isEmpty()) {
			return new ResponseEntity<List>(list,HttpStatus.OK);
		}
		else {
			return new ResponseEntity<List>(list,HttpStatus.OK);
		}
		
	}
	@GetMapping(value="GetStudentByname/{studentName}")
public ResponseEntity<Student> getStudentInfoByName( @PathVariable  String studentName){
		Student student=stuservice.getStudentByname(studentName);
		if(student!=null) {
			return new ResponseEntity<Student>(student,HttpStatus.OK);
		}
		else {
			return new ResponseEntity<Student>(HttpStatus.OK);
		}
	}
	@DeleteMapping(value="DeleteStudentById/{studentId}")
	public ResponseEntity<Boolean> DeleteStudentById( @PathVariable int studentId){
		boolean isDeleted=stuservice.DeleteProductByid(studentId);
		if(isDeleted) {
			return new ResponseEntity<Boolean>(isDeleted,HttpStatus.OK);
		}
		else {
			return new ResponseEntity<Boolean>(HttpStatus.OK);
		}
		
	}
	@PutMapping(value="update Student info")
	public ResponseEntity<Boolean>updateStudent( @RequestBody Student student){
		Boolean isUpdated=stuservice.updateStudent(student);
		if(isUpdated) {
			return new ResponseEntity<Boolean>(isUpdated,HttpStatus.OK);
			
		}
		else {
			return new ResponseEntity<Boolean>(HttpStatus.OK);
		}
	}
	@GetMapping(value="GetStudentInAsccendingOrder")
	public ResponseEntity<List>getStudentByAsscendingOrder(){
		List<Student>li=stuservice.getStudentByAscendingOrder();
		if(!li.isEmpty()) {
			return new ResponseEntity<List>(li,HttpStatus.OK);
		}
		else {
			return new ResponseEntity<List>(HttpStatus.OK);
		}
	}
	@GetMapping(value="Get Student")
	public ResponseEntity<List>getStudentByDescendingOrder(){
		List<Student>list=stuservice.getStudentByDescendingOrder();
		if(!list.isEmpty()) {
			return new ResponseEntity<List>(list,HttpStatus.OK);
		}
		else {
			return new ResponseEntity<List>(HttpStatus.OK);
		}
	}
	@GetMapping(value="get Topper Student")
	public ResponseEntity<Student>getTopper(){
		Student student=stuservice.getTopper();
		if(student!=null) {
			return  new ResponseEntity<Student>(student,HttpStatus.OK);
		}
		else {
			return new ResponseEntity<Student>(HttpStatus.OK);
		}
	}
	@GetMapping(value="Get Lower Student")
	public ResponseEntity<Student> getLowerStudent() {
		Student student=stuservice.getLowerStudent();
		if(student!=null) {
			return new ResponseEntity<Student>(student,HttpStatus.OK);
			
		}
		else {
			return new ResponseEntity<Student>(HttpStatus.OK);
		}
	}
	@GetMapping(value="Get avg per")
	public ResponseEntity<Double>getAvgPer(){
		Double per=stuservice.getAvgPercentage();
		if(per!=0.0) {
			return new ResponseEntity<Double>(per,HttpStatus.OK);
		}
		else {
			return new ResponseEntity<Double>(HttpStatus.OK);
		}
	}
	@GetMapping(value="get Greater per/{per}")
	public ResponseEntity<List>getGreaterPer(@PathVariable double per){
		List<Student> list=stuservice.getGreaterPer(per);
		if(!list.isEmpty()) {
			return  new ResponseEntity<List>(list,HttpStatus.OK);
		}
		else {
			return new ResponseEntity<List>(HttpStatus.OK);
		}
	}
}

package com.jbk.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jbk.dao.StudentDao;
import com.jbk.entity.Student;
@Service
public class StudentServiceImpl implements StudentService {
	@Autowired
	 private StudentDao sdao;

	@Override
	public boolean saveStudentInfo(Student student) {
		boolean b=sdao.saveStudentInfo(student);
		return b;
		
		
	}

	@Override
	public Student getStudentById(int sid) {
		Student student=sdao.getStudentById(sid);
		return student;
	}

	@Override
	public List<Student> getAllStudent() {
		List<Student>list=sdao.getAllStudent();
		return list;
	}

	@Override
	public Student getStudentByname(String StudentName) {
		Student student=sdao.getStudentByname(StudentName);
		return student;
	}

	@Override
	public boolean DeleteProductByid(int sid) {
		boolean isDeleted=sdao.DeleteProductByid(sid);
		return isDeleted;
	}

	@Override
	public boolean updateStudent(Student student) {
		boolean b=sdao.updateStudent(student);
		return b;
	}

	@Override
	public List<Student> getStudentByAscendingOrder() {
		List<Student>li=sdao.getStudentByAscendingOrder();
		return li;
	}

	@Override
	public List<Student> getStudentByDescendingOrder() {
		List<Student>li=sdao.getStudentByAscendingOrder();
		
		return li;
	}

	@Override
	public Student getTopper() {
	Student s=sdao.getTopper();
	return s;
	
	}

	@Override
	public Student getLowerStudent() {
		Student stu=sdao.getLowerStudent();
		return stu;
	}

	@Override
	public double getAvgPercentage() {
		Double d=sdao.getAvgPercentage();
		return d;
	}

	@Override
	public List<Student> getGreaterPer(double per) {
		List<Student>li=sdao.getGreaterPer(per);
		return li;
	}
	
	
	

}

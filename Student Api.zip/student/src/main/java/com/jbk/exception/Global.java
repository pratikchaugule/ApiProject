package com.jbk.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class Global {
	@ExceptionHandler(ProductAlreadyExists.class)
	public ResponseEntity<String>getException(ProductAlreadyExists ex){
		String msg=ex.getMessage();
		return new ResponseEntity<String>(msg,HttpStatus.OK);
		
	}
	

}
